```markdown
# Fitness Coach Landing + Email Scheduler (customized)

I fixed the package.json and added a polished, space-tech-themed landing page that matches the black / white / electric-blue look you requested. The landing page references the Instagram handle @introvert_to_alphafitness and includes two sample email templates (templates/welcome.html and templates/promo.html) that use the %FIRSTNAME% placeholder.

Quick checklist to run:
1. Install
   npm install

2. Create a .env (or set env vars):
   - ADMIN_SECRET (random string used by admin UI)
   - SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS
   - FROM_EMAIL (optional)
   - PORT (optional, default 3000)

3. Start
   npm start

Files added/updated:
- package.json (fixed)
- public/index.html (new look + copy)
- public/style.css (space-tech theme)
- public/app.js (small UX polish)
- templates/welcome.html (sample %FIRSTNAME% email)
- templates/promo.html (sample promo email)

Notes:
- The admin UI you already have (public/admin.html + public/admin.js + server endpoints) will let you create campaigns and paste either of these templates into the body when composing.
- Test sending with a small test email before mailing the whole list.
- For higher deliverability/scale, consider integrating a delivery provider (SendGrid/Mailgun/SES) or using their API instead of SMTP.

If you want, I can:
- Replace the Unsplash placeholder with a pro photo from the Instagram account (I can extract & suggest images if you want me to fetch them),
- Create 2–3 ready-to-use campaign drafts (subject + body) tailored to the Instagram voice,
- Add an unsubscribe link + footer compliance template to emails,
- Or make the admin UI look like the new theme (dark / blue) and add an email template picker.