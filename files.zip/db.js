// Simple sqlite DB helper using better-sqlite3
const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname, 'data.sqlite'));

function init() {
  db.prepare(`
    CREATE TABLE IF NOT EXISTS subscribers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      firstName TEXT,
      createdAt TEXT NOT NULL
    )
  `).run();

  db.prepare(`
    CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject TEXT NOT NULL,
      body TEXT NOT NULL,
      sendAt TEXT,
      status TEXT NOT NULL DEFAULT 'scheduled',
      createdAt TEXT NOT NULL
    )
  `).run();

  db.prepare(`
    CREATE TABLE IF NOT EXISTS campaign_sends (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaignId INTEGER,
      email TEXT,
      firstName TEXT,
      status TEXT,
      error TEXT,
      sentAt TEXT
    )
  `).run();
}

init();

module.exports = {
  upsertSubscriber(email, firstName) {
    const now = new Date().toISOString();
    const existing = db.prepare('SELECT id FROM subscribers WHERE email = ?').get(email);
    if (existing) {
      db.prepare('UPDATE subscribers SET firstName = ?, createdAt = ? WHERE id = ?').run(firstName, now, existing.id);
      return existing.id;
    } else {
      const info = db.prepare('INSERT INTO subscribers (email, firstName, createdAt) VALUES (?, ?, ?)').run(email, firstName, now);
      return info.lastInsertRowid;
    }
  },
  getAllSubscribers() {
    return db.prepare('SELECT id, email, firstName, createdAt FROM subscribers ORDER BY createdAt DESC').all();
  },
  countSubscribers() {
    const r = db.prepare('SELECT COUNT(*) as c FROM subscribers').get();
    return r.c;
  },
  createCampaign(subject, body, sendAt) {
    const now = new Date().toISOString();
    const info = db.prepare('INSERT INTO campaigns (subject, body, sendAt, status, createdAt) VALUES (?, ?, ?, ?, ?)').run(subject, body, sendAt, 'scheduled', now);
    return info.lastInsertRowid;
  },
  getAllCampaigns() {
    return db.prepare('SELECT id, subject, body, sendAt, status, createdAt FROM campaigns ORDER BY createdAt DESC').all();
  },
  getCampaignById(id) {
    return db.prepare('SELECT id, subject, body, sendAt, status, createdAt FROM campaigns WHERE id = ?').get(id);
  },
  updateCampaign(id, subject, body, sendAt) {
    const existing = this.getCampaignById(id);
    if (!existing) throw new Error('Campaign not found');
    db.prepare('UPDATE campaigns SET subject = ?, body = ?, sendAt = ?, status = ? WHERE id = ?').run(subject || existing.subject, body || existing.body, sendAt, 'scheduled', id);
  },
  getDueCampaigns(nowIso) {
    return db.prepare("SELECT id, subject, body, sendAt, status, createdAt FROM campaigns WHERE status = 'scheduled' AND (sendAt IS NOT NULL AND sendAt <= ?)").all(nowIso);
  },
  markCampaignAsSent(id) {
    db.prepare("UPDATE campaigns SET status = 'sent' WHERE id = ?").run(id);
  },
  recordCampaignSends(campaignId, results) {
    const stmt = db.prepare('INSERT INTO campaign_sends (campaignId, email, firstName, status, error, sentAt) VALUES (?, ?, ?, ?, ?, ?)');
    const now = new Date().toISOString();
    const insert = db.transaction((rows) => {
      for (const r of rows) {
        stmt.run(campaignId, r.email, r.firstName || '', r.ok ? 'sent' : 'failed', r.error || '', r.sentAt || now);
      }
    });
    insert(results);
  }
};