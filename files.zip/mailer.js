// Mail sending logic (nodemailer). Uses SMTP credentials from environment.
// Supports personalization: replace %FIRSTNAME% in body.
const nodemailer = require('nodemailer');

function getTransporter() {
  // Allow using standard SMTP or a SendGrid/other SMTP-compatible service.
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) {
    throw new Error('SMTP_HOST and SMTP_USER must be set in environment variables.');
  }
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true', // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

async function sendCampaign(campaign, subscribers) {
  const transporter = getTransporter();
  const from = process.env.FROM_EMAIL || process.env.SMTP_USER;
  const results = [];
  // send sequentially to reduce burst; for large lists consider batching/queue/3rd-party
  for (const s of subscribers) {
    const personalized = (campaign.body || '').replace(/%FIRSTNAME%/g, s.firstName || '');
    const mailOptions = {
      from,
      to: s.email,
      subject: campaign.subject,
      html: personalized
    };
    const resObj = { email: s.email, firstName: s.firstName };
    try {
      await transporter.sendMail(mailOptions);
      resObj.ok = true;
      resObj.error = null;
      resObj.sentAt = new Date().toISOString();
    } catch (err) {
      console.error('send error', s.email, err && err.message);
      resObj.ok = false;
      resObj.error = (err && err.message) || 'unknown';
      resObj.sentAt = new Date().toISOString();
    }
    // small sleep to avoid SMTP throttling
    await new Promise(r => setTimeout(r, Number(process.env.MAIL_DELAY_MS || 200)));
    results.push(resObj);
  }
  return results;
}

module.exports = { sendCampaign };