// Simple Express backend to accept subscribers and manage campaigns
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cron = require('node-cron');
const db = require('./db');
const mailer = require('./mailer');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const ADMIN_HEADER = 'x-admin-secret';

// Helper middleware for admin routes
function requireAdmin(req, res, next) {
  const token = req.header(ADMIN_HEADER);
  if (!process.env.ADMIN_SECRET) {
    return res.status(500).json({ error: 'ADMIN_SECRET not configured on server' });
  }
  if (!token || token !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

// PUBLIC: Subscribe endpoint
app.post('/api/subscribe', async (req, res) => {
  try {
    const { email, firstName } = req.body || {};
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Valid email required' });
    }
    db.upsertSubscriber(email.toLowerCase(), firstName || '');
    return res.json({ success: true });
  } catch (err) {
    console.error('subscribe error', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

// ADMIN: list subscribers
app.get('/api/admin/subscribers', requireAdmin, (req, res) => {
  try {
    const rows = db.getAllSubscribers();
    res.json({ subscribers: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// ADMIN: create campaign (schedule or immediate)
app.post('/api/admin/campaigns', requireAdmin, (req, res) => {
  try {
    const { subject, body, sendAt } = req.body || {};
    if (!subject || !body) return res.status(400).json({ error: 'subject and body required' });
    // sendAt optional ISO datetime (string). If omitted -> send immediately.
    const id = db.createCampaign(subject, body, sendAt || null);
    res.json({ success: true, id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// ADMIN: list campaigns
app.get('/api/admin/campaigns', requireAdmin, (req, res) => {
  try {
    const rows = db.getAllCampaigns();
    res.json({ campaigns: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// ADMIN: update campaign (subject/body/sendAt)
app.put('/api/admin/campaigns/:id', requireAdmin, (req, res) => {
  try {
    const id = Number(req.params.id);
    const { subject, body, sendAt } = req.body || {};
    db.updateCampaign(id, subject, body, sendAt || null);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// ADMIN: trigger send now for campaign
app.post('/api/admin/campaigns/:id/send', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const campaign = db.getCampaignById(id);
    if (!campaign) return res.status(404).json({ error: 'campaign not found' });
    // Immediately queue/send campaign
    await sendCampaignNow(campaign);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// ADMIN: stats
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  try {
    const total = db.countSubscribers();
    const campaigns = db.getAllCampaigns();
    res.json({ totalSubscribers: total, campaignsCount: campaigns.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

// Function to send a campaign (used both by cron and manual trigger)
async function sendCampaignNow(campaign) {
  const subscribers = db.getAllSubscribers();
  if (!subscribers || subscribers.length === 0) {
    db.markCampaignAsSent(campaign.id);
    return;
  }
  // Send and track results
  const results = await mailer.sendCampaign(campaign, subscribers);
  // store logs (basic)
  db.recordCampaignSends(campaign.id, results);
  db.markCampaignAsSent(campaign.id);
}

// Cron: run every minute to check scheduled campaigns
cron.schedule('* * * * *', async () => {
  try {
    const nowIso = new Date().toISOString();
    const due = db.getDueCampaigns(nowIso);
    for (const campaign of due) {
      console.log('Sending scheduled campaign', campaign.id, campaign.subject);
      await sendCampaignNow(campaign);
    }
  } catch (err) {
    console.error('Cron error', err);
  }
});

// Serve index.html by default
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on ${port}`);
  console.log('Make sure to set SMTP_* env vars and ADMIN_SECRET before sending emails.');
});